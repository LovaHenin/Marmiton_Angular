import { Component, OnInit } from '@angular/core';
import { RecetteService } from '../services/recette.service';
import { CategorieService } from '../services/categorie.service';

@Component({
  selector: 'app-liste-recipe',
  templateUrl: './liste-recipe.component.html',
  styleUrls: ['./liste-recipe.component.css'],
})
export class ListeRecipeComponent {
  // constructeur pour utiliser le service
  constructor(
    private rs: RecetteService,
    private rs1:CategorieService,
    ) {}
   
  recipes1: any[]=[];
  recipes: any;
  categories: any;

  delete(id: any) {
    this.rs.deleteRecipe(id);
    // refress=> recharge de DOM
    this.ngOnInit();
  }
  //ajouter dans import
  ngOnInit(): void {
    // recuperer recipes de la session via service
    this.recipes = this.rs.readRecipes();
    // recuperer les categories dans categorie.service
    this.categories = this.rs1.readCategories();
  }
  selectedOption: any; // Vous pouvez déclarer ici le type approprié pour l'id (number, string, etc.)

  onOptionSelected(selectedId: number) {
        // Faites quelque chose en fonction de l'id sélectionné
        console.log('ID sélectionné :', selectedId);
   
   this.recipes1=(this.rs.afficheCategorie(selectedId));
   console.log(this.recipes1);
   
  }
}
